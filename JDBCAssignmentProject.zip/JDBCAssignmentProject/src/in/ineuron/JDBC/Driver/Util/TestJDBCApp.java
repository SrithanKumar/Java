package in.ineuron.JDBC.Driver.Util;

import java.sql.*;

import java.util.Scanner;

import in.neuron.dynamicinput.JDBC.Operations.*;

public class TestJDBCApp {

	public void userInput() throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("User please select the number of operation to be performed:: ");
		int value = sc.nextInt();

		switch (value) {
		case 1:
			InsertApp.insertQueryApp();
			break;
		case 2:
			SelectApp.selectQueryApp();
			break;
		case 3:
			UpdateApp.updateQueryApp();
			break;
		case 4:
			DeleteApp.deleteQueryApp();
			break;
		default:
			System.out.println("*****INVALID INPUT********** ");

		}
	}

	public static void main(String[] args) throws SQLException {

		System.out.println("=========WELCOME TO JDBC OPERATIONS=========");
		System.out.println("MENU");
		System.out.print("1.CREATE \n");
		System.out.print("2.READ \n");
		System.out.print("3.UPDATE \n");
		System.out.print("4.DELETE \n");

		TestJDBCApp tapp = new TestJDBCApp();
		tapp.userInput();

		System.out.println("\n ====THANK YOU FOR USING THE APPLICATION========");
	}

}
